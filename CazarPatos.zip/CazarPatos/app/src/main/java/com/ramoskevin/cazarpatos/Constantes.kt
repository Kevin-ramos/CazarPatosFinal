package com.ramoskevin.cazarpatos

const val EXTRA_LOGIN = "EXTRA_LOGIN"
const val LOGIN_KEY = "LOGIN_KEY"
const val PASSWORD_KEY = "PASSWORD_KEY"